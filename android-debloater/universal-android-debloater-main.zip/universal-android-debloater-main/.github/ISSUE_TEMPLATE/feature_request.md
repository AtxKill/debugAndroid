---
name: Feature request
about: You want a new feature
title: ""
labels: enhancement
assignees: ""
---

**Describe the feature you want**
A clear description of what you want to happen.
